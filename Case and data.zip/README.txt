## 🔄 Simulation Files

The repository includes a ZIP archive containing ANSYS Fluent case and data files for three different mesh configurations used in the grid sensitivity study:

- **29K cells** – Coarse mesh
- **58K cells** – Medium-resolution mesh (balanced accuracy and computational cost)
- **116K cells** – Fine mesh (high-resolution for detailed flow capture)

Each mesh configuration includes:
- `.cas` – Case file with solver settings, turbulence model, boundary conditions, etc.
- `.dat` – Data file with simulation results
